package com.agile.cah.eit.plm.interfaceutil;

import java.util.Calendar;
import java.util.Hashtable;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.agile.cah.eit.plm.interfaceBean.BPCSJMSBean;
import com.agile.cah.eit.plm.interfaceBean.VasteraJMSBean;
import com.ibm.mq.MQException;
import com.ibm.mq.MQQueueManager;
import com.ibm.mq.MQTopic;
import com.ibm.mq.constants.CMQC;

/**
 * Description : This java class will connect to a queue manager and publish a
 * message to a topic.
 * 
 * @author rasmi.raghavan
 * @version 1.0
 * 
 * @Created : Apr 15, 2018
 * 
 *          Added for CAH Agile Release 7.0
 */
public class MQPublisher {

	static Logger log;
	static {
		log = LogManager.getLogger(MQPublisher.class);

	}

	private Hashtable<String, Object> bpcsMQht = null;
	private Hashtable<String, Object> vasteraMQht = null;
	private String qMgrName;
	private String topicString = null;
	public static MQQueueManager _qMgrVastera = null;
	public static String bpcs_error_message = null;
	public static String vastera_error_message = null;

	/**
	 * The constructor
	 */
	public MQPublisher() {
		super();
		log.info("MQPublisher Initialised @ "
				+ Calendar.getInstance().getTime());
	}

	/**
	 * Method to initialise BPCS Context object having MessageQueue details
	 * 
	 * @param bpcsBean
	 *            Bean class containing BPCS properties
	 * @return Hashtable containing mQ details
	 */

	public Hashtable<String, Object> initBpcsContext(BPCSJMSBean bpcsBean) {

		bpcsMQht = new Hashtable<String, Object>();

		System.setProperty("com.ibm.mq.cfg.useIBMCipherMappings", "false");

		//System.setProperty("javax.net.ssl.trustStore","\\data\\java\\jdk1.8.0_172\\jre\\lib\\security\\dev_trustStore.jks");
		System.setProperty("javax.net.ssl.trustStore",bpcsBean.getTruststore());
		System.setProperty("javax.net.ssl.trustStorePassword", bpcsBean.getTruststorepwd());

		//System.setProperty("javax.net.ssl.keyStore","\\data\\java\\jdk1.8.0_172\\jre\\lib\\security\\ldec0608agl03.appzone.dmz.jks");
		System.setProperty("javax.net.ssl.keyStore",bpcsBean.getKeystore());
		System.setProperty("javax.net.ssl.keyStorePassword", bpcsBean.getKeystorepwd());
		
		
		log.info("  SSLTrustStore = "+ System.getProperty("javax.net.ssl.trustStore"));
		log.info("  SSLKeyStore = "+ System.getProperty("javax.net.ssl.keyStore"));
		//log.info("  SSLKeyStorePassword = "+ System.getProperty("javax.net.ssl.keyStorePassword"));
		//log.info("  SSLTrustStorePassword = "+ System.getProperty("javax.net.ssl.trustStorePassword"));
		log.info("  SSLCipher = "+ bpcsBean.getSSL_CIPHER_SUITE_PROPERTY());

		

		
		bpcsMQht.put(CMQC.CHANNEL_PROPERTY, bpcsBean.getChannel());
		bpcsMQht.put(CMQC.HOST_NAME_PROPERTY, bpcsBean.getHostname());
	    //bpcsMQht.put(CMQC.SSL_CIPHER_SUITE_PROPERTY, "TLS_RSA_WITH_AES_128_CBC_SHA256");
		bpcsMQht.put(CMQC.SSL_CIPHER_SUITE_PROPERTY, bpcsBean.getSSL_CIPHER_SUITE_PROPERTY());
	    
		
		try {
			bpcsMQht.put(CMQC.PORT_PROPERTY, new Integer(bpcsBean.getMqPort()));
		} catch (NumberFormatException e) {
			bpcsMQht.put(CMQC.PORT_PROPERTY, new Integer(1414));
		} catch (NullPointerException ne) {
			bpcsMQht.put(CMQC.PORT_PROPERTY, new Integer(1414));
		}
		return bpcsMQht;
	}

	/**
	 * Method to initialise Vastera Context object having MessageQueue details
	 * 
	 * @param vasteraBean
	 *            Bean class containing Vastera properties
	 * @return Hashtable containing mQ details
	 */
	public Hashtable<String, Object> initVasteraContext(
			VasteraJMSBean vasteraBean) {

		vasteraMQht = new Hashtable<String, Object>();
		System.setProperty("com.ibm.mq.cfg.useIBMCipherMappings", "false");
		System.setProperty("javax.net.ssl.trustStore",vasteraBean.getTruststore());
		System.setProperty("javax.net.ssl.trustStorePassword", vasteraBean.getTruststorepwd());
		System.setProperty("javax.net.ssl.keyStore",vasteraBean.getKeystore());
		System.setProperty("javax.net.ssl.keyStorePassword", vasteraBean.getKeystorepwd());
		
		
		vasteraMQht.put(CMQC.CHANNEL_PROPERTY, vasteraBean.getChannel());
		vasteraMQht.put(CMQC.HOST_NAME_PROPERTY, vasteraBean.getHostname());
		vasteraMQht.put(CMQC.SSL_CIPHER_SUITE_PROPERTY, vasteraBean.getSSL_CIPHER_SUITE_PROPERTY());
		
		
		log.info("  SSLTrustStore = "+ System.getProperty("javax.net.ssl.trustStore"));
		log.info("  SSLKeyStore = "+ System.getProperty("javax.net.ssl.keyStore"));
		//log.info("  SSLKeyStorePassword = "+ System.getProperty("javax.net.ssl.keyStorePassword"));
		//log.info("  SSLTrustStorePassword = "+ System.getProperty("javax.net.ssl.trustStorePassword"));
		log.info("  SSLCipher = "+ vasteraBean.getSSL_CIPHER_SUITE_PROPERTY());


		try {
			vasteraMQht.put(CMQC.PORT_PROPERTY,
					new Integer(vasteraBean.getMqPort()));
		} catch (NumberFormatException e) {
			vasteraMQht.put(CMQC.PORT_PROPERTY, new Integer(1414));
		} catch (NullPointerException ne) {
			vasteraMQht.put(CMQC.PORT_PROPERTY, new Integer(1414));
		}
		return vasteraMQht;
	}

	/**
	 * Method to get BPCS connection
	 * 
	 * @param mqht
	 *            Hashtable having BPCS MQ details
	 * @param bpcsBean
	 *            Bean class containing BPCS properties
	 * @return MQQueueManager
	 */
	public MQQueueManager getBpcsMQConnection(Hashtable<String, Object> mqht,
			BPCSJMSBean bpcsBean) {

		MQQueueManager _qMgr = null;
		qMgrName = bpcsBean.getQueueManager();

		try {
			// Get BPCS QueueManager
			_qMgr = new MQQueueManager(qMgrName, mqht);
			
			log.info("connected to BPCS queue manager: " + qMgrName);

		} catch (MQException e) {

			bpcs_error_message = e.getMessage() + "\n" + "MQException CC="
					+ e.completionCode + " : RC=" + e.reasonCode;
			e.printStackTrace();
			log.error("MQException CC=" + e.completionCode + " : RC="
					+ e.reasonCode);
			log.error("Unable to connect to MQ for Queue " + qMgrName);
			return null;
		}
		log.info("Able to open the BPCS Queue");
		return _qMgr;
	}

	/**
	 * Method to get Vastera connection
	 * 
	 * @param mqht
	 *            Hashtable having Vastera MQ details
	 * @param vasteraBean
	 *            Bean class containing Vastera properties
	 * @return MQTopic
	 */
	public MQTopic getVasteraMQConnection(Hashtable<String, Object> mqht,
			VasteraJMSBean vasteraBean) {

		MQTopic publisher = null;
		qMgrName = vasteraBean.getQueueManager();
		topicString = vasteraBean.getTopicString();

		try {
			// get Vastera QueueManager
			_qMgrVastera = new MQQueueManager(qMgrName, mqht);
			log.info("connected to Vastera queue manager: " + _qMgrVastera);
			log.info("%%%%%%%%%%%%% Vastera Topic String " + topicString);

			// Connect to the Vastera Topic String
			publisher = _qMgrVastera.accessTopic(topicString, "",
					CMQC.MQTOPIC_OPEN_AS_PUBLICATION, CMQC.MQOO_OUTPUT);
			log.info("TopicString opened for : " + publisher.getName());

		} catch (MQException e) {

			e.printStackTrace();
			vastera_error_message = e.getMessage() + "\n" + "MQException CC="
					+ e.completionCode + " : RC=" + e.reasonCode;
			log.error("MQException CC=" + e.completionCode + " : RC="
					+ e.reasonCode);
			log.error("Unable to connect to vastera MQ for Queue " + qMgrName);
			return null;
		}
		log.info("Able to open the Vastera Queue");
		return publisher;
	}

}
