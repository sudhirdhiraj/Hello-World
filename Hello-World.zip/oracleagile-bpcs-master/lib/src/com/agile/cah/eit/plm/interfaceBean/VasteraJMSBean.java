package com.agile.cah.eit.plm.interfaceBean;

/**
 * Description : Bean class to hold vastera JMS and email properties
 * 
 * @author rasmi.raghavan
 * @version 1.0
 * 
 * @Created : Apr 15, 2018
 * 
 *          Added for CAH Agile Release 7.0
 */
public class VasteraJMSBean {

	private String vastera_Sites;
	private String queueManager;
	private String channel;
	private String hostname;
	private String mqPort;
	private String topicString;
	private String queueName;
	private String mqEMailAddress;
	private String agileSupporteMailAddress;
	private String vasteraeMailAddress;
	private String mailSubject;
	private String keystore;
	private String SSL_CIPHER_SUITE_PROPERTY;
	public String getKeystore() {
		return keystore;
	}

	public void setKeystore(String keystore) {
		this.keystore = keystore;
	}

	public String getSSL_CIPHER_SUITE_PROPERTY() {
		return SSL_CIPHER_SUITE_PROPERTY;
	}

	public void setSSL_CIPHER_SUITE_PROPERTY(String sSL_CIPHER_SUITE_PROPERTY) {
		SSL_CIPHER_SUITE_PROPERTY = sSL_CIPHER_SUITE_PROPERTY;
	}

	public String getKeystorepwd() {
		return keystorepwd;
	}

	public void setKeystorepwd(String keystorepwd) {
		this.keystorepwd = keystorepwd;
	}

	public String getTruststore() {
		return truststore;
	}

	public void setTruststore(String truststore) {
		this.truststore = truststore;
	}

	public String getTruststorepwd() {
		return truststorepwd;
	}

	public void setTruststorepwd(String truststorepwd) {
		this.truststorepwd = truststorepwd;
	}

	private String keystorepwd;
	private String truststore;
	private String truststorepwd;

	
	
	public String getVastera_Sites() {
		return vastera_Sites;
	}

	public void setVastera_Sites(String vastera_Sites) {
		this.vastera_Sites = vastera_Sites;
	}

	public String getQueueManager() {
		return queueManager;
	}

	public void setQueueManager(String queueManager) {
		this.queueManager = queueManager;
	}

	public String getChannel() {
		return channel;
	}

	public void setChannel(String channel) {
		this.channel = channel;
	}

	public String getQueueName() {
		return queueName;
	}

	public void setQueueName(String queueName) {
		this.queueName = queueName;
	}

	public String getMqEMailAddress() {
		return mqEMailAddress;
	}

	public void setMqEMailAddress(String mqEMailAddress) {
		this.mqEMailAddress = mqEMailAddress;
	}

	public String getAgileSupporteMailAddress() {
		return agileSupporteMailAddress;
	}

	public void setAgileSupporteMailAddress(String agileSupporteMailAddress) {
		this.agileSupporteMailAddress = agileSupporteMailAddress;
	}

	public String getVasteraeMailAddress() {
		return vasteraeMailAddress;
	}

	public void setVasteraeMailAddress(String vasteraeMailAddress) {
		this.vasteraeMailAddress = vasteraeMailAddress;
	}

	public String getHostname() {
		return hostname;
	}

	public void setHostname(String hostname) {
		this.hostname = hostname;
	}

	public String getMqPort() {
		return mqPort;
	}

	public void setMqPort(String mqPort) {
		this.mqPort = mqPort;
	}

	public String getTopicString() {
		return topicString;
	}

	public void setTopicString(String topicString) {
		this.topicString = topicString;
	}

	public String getMailSubject() {
		return mailSubject;
	}

	public void setMailSubject(String mailSubject) {
		this.mailSubject = mailSubject;
	}

}
