package com.agile.cah.eit.plm.integrator;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.StringTokenizer;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.agile.cah.eit.plm.interfaceBean.AXMLDataBean;
import com.agile.cah.eit.plm.interfaceBean.PropertiesBean;
import com.agile.cah.eit.plm.interfaceutil.EMailUtil;
import com.agile.cah.eit.plm.interfaceutil.FileUtil;
import com.agile.cah.eit.plm.interfaceutil.InterfaceConstants;
import com.agile.cah.eit.plm.interfaceutil.InterfaceException;
import com.agile.cah.eit.plm.interfaceutil.PropertiesLoader;
import com.agile.cah.eit.plm.xmltools.AXMLParser;
import com.agile.cah.eit.plm.xmltools.BPCSXmlConverter;
import com.agile.cah.eit.plm.xmltools.CanonicalXMLConverter;
import com.agile.cah.eit.plm.xmltools.XMLConverter;

/**
 * Description : Main class to read AXML and convert them to canonical xml &
 * BPCS xml formats.
 * 
 * @author rasmi.raghavan
 * @version 1.0
 * @Created : Apr 15, 2018
 * 
 *          Added for CAH Agile Release 7.0
 */
public class ProcessAgileData {

	static Logger log;
	static {
		log = LogManager.getLogger(ProcessAgileData.class);

	}
	static PropertiesBean propBean = null;

	public static void main(String[] argv) {

		log.info("ProcessAgileData started at : "
				+ Calendar.getInstance().getTime());
		ProcessAgileData sendData = new ProcessAgileData();
		FileUtil fUtil = new FileUtil();
		PropertiesLoader propLoader = new PropertiesLoader();
		try {
			propBean = propLoader
					.loadInterfacePropFile(InterfaceConstants.INTERFACE_PROPERTIES_FILE_NAME);
			log.info("PropertiesBean loaded successfully");

			String axmlFolderForSite = propBean.getFolderPath();

			if (axmlFolderForSite != null && axmlFolderForSite.length() > 0) {

				// get list of site directories in the main AXML directory
				File[] files = fUtil.getDirectories(axmlFolderForSite);

				// loop through each site directory and process the AXMl file
				for (File file : files) {
					String siteName = file.getName();
					log.info("Processing files for Site : " + siteName);
					String siteAxmlFldr = axmlFolderForSite + "/" + siteName;

					// process each site folder
					sendData.processFiles(siteAxmlFldr, fUtil, propBean,
							siteName);

				}
			} else {
				log.error("Axml FolderName for Site - Folder Name value is null or empty");
				throw new InterfaceException(
						"Axml FolderName for Site- Folder Name value is null or empty");
			}

		} catch (InterfaceException interfaceEx) {
			log.error("Error in ProcessAgileData:" + interfaceEx.getMessage());
			interfaceEx.printStackTrace();
		} catch (Exception ex) {
			log.error("Error in ProcessAgileData:" + ex.getMessage());
			ex.printStackTrace();
		}

	}

	/**
	 * Process each site folder, extract each AXML file and convert it to
	 * canonical xml format and then to BPCS xml format
	 * 
	 * @param axmlFolderForSite
	 *            canonical path of site folder
	 * @param fUtil
	 *            instance of FileUtil class
	 * @param propBean
	 *            instance of PropertiesBean class
	 * @param site
	 *            siteID
	 */
	public void processFiles(String axmlFolderForSite, FileUtil fUtil,
			PropertiesBean propBean, String site) {
		log.info("sourceFilePath" + axmlFolderForSite);
		ArrayList<File> zipFileList = new ArrayList<File>();
		AXMLParser axmlParser = new AXMLParser();
		String axmlFileName;
		EMailUtil mailUtil = new EMailUtil();

		// extract the xslt and folder names from properties file
		String canonicalXslt = propBean.getCanonicalXSLT();
		String bpcsXslt = propBean.getBpcsXSLT();
		String errorFldr = axmlFolderForSite + "/" + propBean.getErrorFolder();
		String archiveFldr = axmlFolderForSite + "/"
				+ propBean.getArchiveFolder();
		String opFldrPath = axmlFolderForSite + "/"
				+ propBean.getOutputFolder();
		String vasteraSites = propBean.getVastera_Sites();

		// list for handling errored axml files names
		ArrayList<String> errorList = new ArrayList<String>();
		try {

			// convert all the axml files into zip files for processing
			zipFileList = fUtil.renameAXMLFiles(axmlFolderForSite + "/"
					+ propBean.getInputFolder());

			// process each zip file and extract the axml file
			if (zipFileList != null && zipFileList.size() > 0) {
				File originalAxmlFile = null;
				String originalAxmlFileName;
				for (File zipfile : zipFileList) {

					boolean trans1 = false;
					boolean trans2 = false;
					boolean axmlParserEx = false;
					String zipFileName = zipfile.getName();
					int extensionIndex = zipFileName.lastIndexOf(".");
					String newFileName = zipFileName.substring(0,
							extensionIndex) + ".AXML";
					originalAxmlFile = new File(axmlFolderForSite + "/"
							+ propBean.getInputFolder() + "/" + newFileName);
					originalAxmlFileName = originalAxmlFile.getName();

					// extract the axml file from each zip file
					System.out.println("Zip file = "
							+ zipfile.getAbsolutePath());
					axmlFileName = fUtil.extractAXMLFiles(zipfile);
					AXMLDataBean axmlBean = new AXMLDataBean();
					if (axmlFileName.length() > 0) {
						// parse each axml file
						String newPath = null;
						String newName = null;
						try {
							File axmlFile = new File(axmlFileName);
							newPath = axmlFileName.substring(0,
									axmlFileName.lastIndexOf("/"));
							try {
								// Read required data from AMXL file and set the
								// AXML Bean
								axmlBean = axmlParser.readAttributes(axmlFile);
							} catch (InterfaceException inEx) {
								axmlParserEx = true;
								log.error(inEx.getMessage(), inEx);
							}

							// If AXMl Bean is parsed properly proceed for XML
							// transformations
							if (!axmlParserEx) {
								newName = newPath + "/"
										+ axmlBean.getSelectedObjNo() + ".xml";
								axmlFile.renameTo(new File(newName));

								// get Canonical folder
								fUtil.getDirFile(opFldrPath);
								XMLConverter canonicalConverter = new CanonicalXMLConverter(
										canonicalXslt, newName);
								String newCanonicalXML = opFldrPath + "/"
										+ axmlBean.getSelectedObjNo()
										+ "_Canonical.xml";

								/*
								 * Code to add ATO number to the file name
								 * String newCanonicalXML = opFldrPath + "/" +
								 * axmlBean.getAto_number() + "_" +
								 * axmlBean.getSelectedObjNo() +
								 * "_Canonical.xml";
								 */

								// AXML to Canonical XML transformation
								trans1 = canonicalConverter.transformXML(
										newCanonicalXML, canonicalXslt);
								java.util.concurrent.TimeUnit.MILLISECONDS
										.sleep(500);
								if (!trans1) {
									// If canonical xml transformation failed
									// add AXML file name to error list
									errorList.add(originalAxmlFileName);
									// get error folder
									fUtil.getDirFile(errorFldr);
									// Move AXML file to error folder
									originalAxmlFile.renameTo(new File(
											errorFldr + "/" + newFileName));

								} else {
									log.info("Canonical transformation complete");
								}
								if (trans1) {
									// If canonical xml transformation is
									// success proceed to create BPCS xml

									String bpcsXmlName = opFldrPath + "/"
											+ axmlBean.getSelectedObjNo()
											+ "_Bpcs.xml";
									/*
									 * Code to add ATO number to the file name
									 * String bpcsXmlName = opFldrPath + "/" +
									 * axmlBean.getAto_number() + "_" +
									 * axmlBean.getSelectedObjNo() +
									 * "_Bpcs.xml";
									 */

									// Convert canonical XML to BPCS XML
									XMLConverter bpcsConverter = new BPCSXmlConverter(
											bpcsXslt, newCanonicalXML);
									trans2 = bpcsConverter.transformXML(
											bpcsXmlName, bpcsXslt);
									java.util.concurrent.TimeUnit.MILLISECONDS
											.sleep(500);
									if (!trans2) {
										// If BPCS xml transformation failed add
										// AXML file name to error list
										errorList.add(originalAxmlFileName);
										// get error folder
										fUtil.getDirFile(errorFldr);
										// Move AXML file to error folder
										originalAxmlFile.renameTo(new File(
												errorFldr + "/" + newFileName));
									} else {

										// If BPCS XML is created successfully
										// then replicate if site is also
										// vastera
										// site
										StringTokenizer siteToken = new StringTokenizer(
												vasteraSites, ";");
										while (siteToken.hasMoreTokens()) {
											if (siteToken.nextToken().equals(
													site)) {
												String vFile = bpcsXmlName
														.substring(
																0,
																bpcsXmlName
																		.lastIndexOf("_"))
														+ "_Vastera.xml";
												File vasteraFile = new File(
														vFile);
												File bpcsFile = new File(
														bpcsXmlName);

												// If vastera file doesnt exist
												// then make a copy of BPCS file
												// and name
												// it with vastera.xml suffix
												if (!vasteraFile.exists()) {
													Files.copy(bpcsFile
															.toPath(),
															vasteraFile
																	.toPath());

													// Set last modified is same
													// as the corresponding BPCS
													// xml file
													vasteraFile
															.setLastModified(bpcsFile
																	.lastModified());
												} else {
													log.info("Vastera file already exists : "
															+ vasteraFile);
												}
											}

										}

										log.info("BPCS transformation complete");
										// get archive folder
										fUtil.getDirFile(archiveFldr);

										// If the transformation process is
										// successful then move the AXML file to
										// archive folder
										originalAxmlFile
												.renameTo(new File(archiveFldr
														+ "/" + newFileName));
									}
								}
							} else {
								log.error("Error reading AXML file:");
								// On error move the AXML file to error folder
								originalAxmlFile.renameTo(new File(errorFldr
										+ "/" + newFileName));
							}
						} catch (Exception ioEx) {
							log.error("Exception in parsing :" + ioEx);
							ioEx.printStackTrace();
							// errorList.add(axmlBean.getSelectedObjNo());
							errorList.add(originalAxmlFileName);
							// get error folder
							fUtil.getDirFile(errorFldr);
							// move AXMl file to error folder
							originalAxmlFile.renameTo(new File(errorFldr + "/"
									+ newFileName));

						} finally {

							// Delete any .zip file or .AXML file in the input
							// folder
							boolean fileDel = false;
							boolean fldrDel = false;
							System.out.println("inside finally");
							if (newName != null) {
								File xmlFile = new File(newName);
								System.out
										.println("XML File for del" + xmlFile);
								fileDel = xmlFile.delete();
								if (fileDel) {
									File xmlFldr = new File(newPath);
									fldrDel = xmlFldr.delete();
									if (fileDel && fldrDel)
										log.info("File and folder deleted ");
									else
										log.error("Unable to delete folder "
												+ newPath);
								} else {
									log.error("Unable to delete file "
											+ newName);
								}
							} else {
								File xmlFldr = new File(newPath);
								File fileList[] = xmlFldr.listFiles();
								for (File fileInDir : fileList) {
									fileInDir.delete();
								}

								if ((xmlFldr.list()).length == 0)
									fldrDel = xmlFldr.delete();
								log.info("File and folder deleted ");

							}
							log.info("New Zip file = "
									+ zipfile.getAbsolutePath());
							File zipfileNew = new File(
									zipfile.getAbsolutePath());
							if (zipfileNew.exists()) {
								zipfileNew.setExecutable(true);
								boolean del = zipfileNew.delete();
								log.info("The ZIP file " + zipfileNew
										+ " was deleted " + del);
							}
						}

					} else {
						log.info("No AXML file available");
					}

				}

				if (errorList.size() > 0) {
					// Send error mail if there are axml file names in error
					// list
					log.info("List of error AXML's :" + errorList);
					mailUtil.sendErrorMail(propBean.getToEMailID() + ",",
							propBean.getFromEMailID(),
							propBean.getMailServer(), errorList, site);
				}
			}
		} catch (

		IOException ioEx) {
			log.error("IOException processing site :" + site + ":" + ioEx);
			ioEx.printStackTrace();
		} catch (InterfaceException interfaceEx) {
			log.error("InterfaceException processing site :" + site + ":"
					+ interfaceEx);
			interfaceEx.printStackTrace();
		} catch (Exception Ex) {
			log.error("Exception processing site :" + site + ":" + Ex);
			Ex.printStackTrace();
		}

	}

}
