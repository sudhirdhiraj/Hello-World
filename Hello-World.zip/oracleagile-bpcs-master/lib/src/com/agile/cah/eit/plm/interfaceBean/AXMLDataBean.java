package com.agile.cah.eit.plm.interfaceBean;

/**
 * Description : Bean class to hold few required data from AXML file
 * 
 * @author rasmi.raghavan
 * @version 1.0
 * 
 * @Created : Apr 15, 2018
 * 
 *          Added for CAH Agile Release 7.0
 */
public class AXMLDataBean {

	private static String ato_number;
	private static String selectedObjType;
	private static String selectedObjNo;
	private static String siteID;

	public String getAto_number() {
		return ato_number;
	}

	public void setAto_number(String ato_number) {
		AXMLDataBean.ato_number = ato_number;
	}

	public String getSelectedObjType() {
		return selectedObjType;
	}

	public void setSelectedObjType(String selectedObjType) {
		AXMLDataBean.selectedObjType = selectedObjType;
	}

	public String getSelectedObjNo() {
		return selectedObjNo;
	}

	public void setSelectedObjNo(String selectedObjNo) {
		AXMLDataBean.selectedObjNo = selectedObjNo;
	}

	public String getSiteID() {
		return siteID;
	}

	public void setSiteID(String siteID) {
		AXMLDataBean.siteID = siteID;
	}

}
