package com.agile.cah.eit.plm.interfaceutil;

import java.util.ArrayList;
import java.util.Properties;

import javax.mail.BodyPart;
import javax.mail.Message.RecipientType;
import javax.mail.Multipart;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/**
 * Description : Util class for sending error email to Agile, BPCS and Vastera
 * teams
 * 
 * @author rasmi.raghavan
 * @version 1.0
 * 
 * @Created : Apr 15, 2018
 * 
 *          Added for CAH Agile Release 7.0
 */
public class EMailUtil {

	static Logger log;
	static {
		log = LogManager.getLogger(EMailUtil.class);

	}
	static String bpcsErrorSubject = "Error processing AXML file to BPCS for Site :";
	static String bpcsErrorMailBody = "The following AXML failed while creating BPCS xml: \n";

	/**
	 * Method to send email to agile admin for the list of failed axml files
	 * while transformation
	 * 
	 * @param toEmailIDs
	 *            emailid of Agile admin user to be notified
	 * @param frmEmailIDs
	 *            agile admin email id
	 * @param emailServer
	 *            Email server name
	 * @param errorlist
	 *            List of errored axml file name
	 * @param site
	 *            Site for which the AXML transformation failed
	 * @throws InterfaceException
	 */
	public void sendErrorMail(String toEmailIDs, String frmEmailIDs,
			String emailServer, ArrayList<String> errorlist, String site)
			throws InterfaceException {

		InternetAddress fromAddress = null;
		// InternetAddress toAddress = null;

		MimeMessage msg = null;
		String MsgBodyPart = "";

		// msg.addRecipients(RecipientType.TO, toAddress);

		try {
			System.out.println("Frm ID : " + frmEmailIDs);
			fromAddress = new InternetAddress(frmEmailIDs);

			log.info("toAddress1:" + toEmailIDs);
			InternetAddress[] toAddress1 = InternetAddress.parse(toEmailIDs);

			Properties props = new Properties();
			props.put("mail.smtp.host", emailServer);

			Session mailSession = Session.getDefaultInstance(props);
			msg = new MimeMessage(mailSession);
			msg.setFrom(fromAddress);
			msg.setText(MsgBodyPart, "UTF-8");
			msg.addRecipients(RecipientType.TO, toAddress1);
			BodyPart messageBodyPart = new MimeBodyPart();
			msg.setSubject(bpcsErrorSubject + site);
			MsgBodyPart = bpcsErrorMailBody;
			for (String axmlName : errorlist) {
				MsgBodyPart += "\n  AXML File : " + axmlName + "\n";
			}

			messageBodyPart.setText(MsgBodyPart);
			Multipart multipart = new MimeMultipart();
			multipart.addBodyPart(messageBodyPart);
			msg.setContent(multipart);
			Transport.send(msg);
			log.info("MAIL SUCCESSFULLY  SENT TO------>:"
					+ toAddress1.toString());

		} catch (Exception ex) {
			ex.printStackTrace();
			log.error(ex.getMessage());
			throw new InterfaceException(
					"Exception sending error mail for XML transformation failure: Site -"
							+ site, ex);
		}

	}

	/**
	 * Method to send email to Agile, BPCS and/Or Vastera team on failure to
	 * connect to the respective Message Queue
	 * 
	 * @param toEmailIDs
	 *            Agile, BPCS and/Or Vastera team email id
	 * @param frmEmailIDs
	 *            agile admin email id
	 * @param emailServer
	 *            Email server name
	 * @param errorMsg
	 *            Connection failure message
	 * @param queueMgrName
	 *            Message Queue name
	 * @param subject
	 *            email Subject
	 * @throws InterfaceException
	 */
	public void sendMQErrorMail(String toEmailIDs, String frmEmailIDs,
			String emailServer, String errorMsg, String queueMgrName,
			String subject) throws InterfaceException {

		InternetAddress fromAddress = null;
		// InternetAddress toAddress = null;
		MimeMessage msg = null;
		String MsgBodyPart = "";

		try {

			fromAddress = new InternetAddress(frmEmailIDs);
			log.info("toAddress1:" + toEmailIDs);
			InternetAddress[] toAddress1 = InternetAddress.parse(toEmailIDs);

			Properties props = new Properties();
			props.put("mail.smtp.host", emailServer);

			Session mailSession = Session.getDefaultInstance(props);
			msg = new MimeMessage(mailSession);
			msg.setFrom(fromAddress);
			msg.setText(MsgBodyPart, "UTF-8");
			msg.addRecipients(RecipientType.TO, toAddress1);
			BodyPart messageBodyPart = new MimeBodyPart();
			msg.setSubject(subject + queueMgrName);

			MsgBodyPart = subject + queueMgrName;
			MsgBodyPart += "\n  Error Message : " + errorMsg + "\n";

			messageBodyPart.setText(MsgBodyPart);
			Multipart multipart = new MimeMultipart();
			multipart.addBodyPart(messageBodyPart);
			msg.setContent(multipart);
			Transport.send(msg);
			log.info("MAIL SUCCESSFULLY  SENT TO------>:"
					+ toAddress1.toString());
		} catch (Exception ex) {
			ex.printStackTrace();
			log.error(ex.getMessage());
			throw new InterfaceException(
					"Exception sending MQ error email - QueueManager: "
							+ queueMgrName, ex);
		}

	}

}
