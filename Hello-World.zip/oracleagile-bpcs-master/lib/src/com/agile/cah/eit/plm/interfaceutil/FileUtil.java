package com.agile.cah.eit.plm.interfaceutil;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileFilter;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.Date;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

import javax.xml.parsers.ParserConfigurationException;

import org.xml.sax.SAXException;

/**
 * Description : FileUtil contains helper methods for working with file objects
 * 
 * @author rasmi.raghavan
 * 
 * @Created : Apr 15, 2018
 * 
 *          Added for CAH Agile Release 7.0
 */
public class FileUtil {

	static org.apache.logging.log4j.Logger log;

	static {
		log = org.apache.logging.log4j.LogManager.getLogger(FileUtil.class);
	}

	/**
	 * This method sorts all the files in the given directory based on the
	 * chronological order using int timestamp and returns back the sorted list
	 * 
	 * @param filepath
	 *            - absolute Path of the Directory
	 * @return File[]- sorted files array
	 * 
	 */
	public File[] sortFiles(String filepath) {
		File mainDir = new File(filepath);
		File[] files = mainDir.listFiles();
		Comparator fileComparator = new Comparator() {

			public int compare(Object o1, Object o2) {
				File file1 = (File) o1;
				File file2 = (File) o2;

				return (int) (file1.lastModified() - file2.lastModified());
			}

		};

		Arrays.sort(files, fileComparator);
		for (File f : files)
			log.info("Sorted list :: " + f.getName());
		return files;
	}

	/**
	 * This method sorts all the files in the given directory based on the
	 * chronological order using long timestamp and returns back the sorted list
	 * 
	 * @param filepath
	 *            - absolute Path of the Directory
	 * @return File[]- sorted files array
	 * 
	 */
	public File[] sortFilesNew(String filepath) {
		File mainDir = new File(filepath);
		File[] files = mainDir.listFiles();
		Arrays.sort(files, new Comparator<File>() {
			public int compare(File file1, File file2) {
				return Long.valueOf(file1.lastModified()).compareTo(
						file2.lastModified());
			}
		});

		for (File f : files)
			log.info("Sorted list :: " + f.getName());
		return files;
	}

	/**
	 * Converts all the axml file in the given location to zip files and returns
	 * the list of zip files
	 * 
	 * @param fileLoc
	 *            - axml files location
	 * @return File[] - array list of zip files
	 * @throws IOException
	 * @throws SAXException
	 * @throws ParserConfigurationException
	 */

	public ArrayList<File> renameAXMLFiles(String fileLoc) throws IOException {

		ArrayList<File> zipFiles = new ArrayList<File>();
		String srcExtn = "";
		String targetExtension = "zip";
		File[] filesInDir = sortFiles(fileLoc);
		InputStream inStr = null;
		OutputStream opStr = null;

		File file = null;
		if (filesInDir.length > 0) {
			for (int i = 0; i < filesInDir.length; i++) {

				log.info("file:" + filesInDir[i].getName());
				file = filesInDir[i];
				srcExtn = filesInDir[i].getName().substring(
						filesInDir[i].getName().indexOf(".") + 1);

				log.debug("srcExtn:" + srcExtn);
				String toFileName = "";
				if (srcExtn.equalsIgnoreCase("axml")) {
					toFileName = filesInDir[i].getName().replace(srcExtn,
							targetExtension);

					log.debug("File name now ::" + filesInDir[i]);

					File renametoZip = new File(fileLoc + "/" + toFileName);

					log.info("Changed filename:" + renametoZip.getName());
					log.info("Existing filename:" + file.getName());

					inStr = new FileInputStream(file);
					opStr = new FileOutputStream(renametoZip);

					byte[] buffer = new byte[1024];
					int len;
					while ((len = inStr.read(buffer)) > 0) {
						opStr.write(buffer, 0, len);
					}
					inStr.close();
					opStr.close();
					zipFiles.add(renametoZip);

				}

			}

		}
		return zipFiles;

	}

	/**
	 * Method to Check if the directory exists with the given name else create
	 * new directory with that name
	 * 
	 * @param dirName
	 *            Directory name
	 * @return boolean
	 */
	public boolean getDirFile(String dirName) {
		File folderDir = new File(dirName);
		if (!folderDir.exists())
			folderDir.mkdir();
		return true;

	}

	/**
	 * Extracts the files from zip file and returns the axml file name
	 * 
	 * @param zipFile
	 *            - Zip file
	 * 
	 * @return String - axml file name
	 */

	public String extractAXMLFiles(File zipFile) throws InterfaceException {

		String axmlFileName = "";
		int BUFFER_SIZE = 2048;
		FileInputStream fileIs = null;
		ZipInputStream zipIs = null;

		try {
			log.info("Processing file :: " + zipFile.getAbsolutePath());
			Date timeStamp = new Date(zipFile.lastModified());
			log.info("File timestamp :: " + timeStamp);
			String fileLoc = zipFile.getAbsolutePath().substring(0,
					zipFile.getAbsolutePath().lastIndexOf("."));
			fileIs = new FileInputStream(zipFile);
			zipIs = new ZipInputStream(new BufferedInputStream(fileIs));
			ZipEntry entry = null;
			String fileName = "";
			String outputFilename = "";
			File axmlFldr = new File(fileLoc);
			if (!axmlFldr.exists())
				axmlFldr.mkdir();
			while ((entry = zipIs.getNextEntry()) != null) {

				fileName = entry.getName();
				log.debug("Extracting file:" + fileName);
				outputFilename = fileLoc + "/" + fileName;

				log.debug("outputFilename:" + outputFilename);
				if (fileName.equals("agile.xml")) {

					FileOutputStream fos = new FileOutputStream(outputFilename);
					BufferedOutputStream dest = null;
					int count;
					byte data[] = new byte[BUFFER_SIZE];
					dest = new BufferedOutputStream(fos, BUFFER_SIZE);
					while ((count = zipIs.read(data, 0, BUFFER_SIZE)) != -1) {
						dest.write(data, 0, count);
					}
					dest.flush();
					dest.close();
					fos.close();
					axmlFileName = outputFilename;

				}
			}
		} catch (Exception ex) {
			log.error("Error while extracting AXML file : " + ex);
			throw new InterfaceException("Error while extracting AXML file ",
					ex);
		} finally {
			try {
				fileIs.close();
				zipIs.close();
			} catch (IOException ioex) {
				log.error("Unable to close the zip file stream"
						+ ioex.getMessage());
				throw new InterfaceException(
						"Unable to close the zip file stream", ioex);
			}
		}
		return axmlFileName;

	}

	/**
	 * copies the file from the source path to the destination location
	 * 
	 * @param sourcePath
	 *            - source location
	 * @param destFilePath
	 *            - destination location
	 * @param fileName
	 *            - file name in the source path to be copied
	 * @throws IOException
	 */
	public void copyFile(String sourcePath, String destFilePath, String fileName)
			throws IOException {

		File source = new File(sourcePath);

		InputStream in = new FileInputStream(source);

		copyStreamToFile(in, new File(destFilePath + "/" + fileName));

		log.info("File was copied to destination folder " + fileName);

	}

	/**
	 * copy the content of stream to file
	 * 
	 * @param in
	 *            - input stream with data
	 * @param file
	 *            - file to which the content from stream needs to be copied
	 * @throws IOException
	 */
	private static void copyStreamToFile(InputStream in, File file)
			throws IOException {

		FileOutputStream out = new FileOutputStream(file);

		try {
			copyStreamToStream(in, out);
		} finally {
			out.close();
		}

	}

	/**
	 * Code to copy between input and output streams
	 * 
	 * @param in
	 *            - input stream
	 * @param out
	 *            - output stream
	 * @throws IOException
	 */
	private static void copyStreamToStream(InputStream in, OutputStream out)
			throws IOException {
		byte[] buf = new byte[4096];
		int amt;

		while ((amt = in.read(buf)) > 0) {
			out.write(buf, 0, amt);
		}
		out.flush();
		out.close();
	}

	/**
	 * Returns a list of directories in the specified directory
	 * 
	 * @param axmlDir
	 *            Main directory name with the canonical path
	 * @return list of directories
	 * @throws InterfaceException
	 */
	public File[] getDirectories(String axmlDir) throws InterfaceException {
		// ArrayList<String> dirList = new ArrayList<String>();
		File[] directories = null;
		try {
			directories = new File(axmlDir).listFiles(new FileFilter() {
				public boolean accept(File file) {
					return file.isDirectory();
				}
			});
		} catch (Exception ex) {
			throw new InterfaceException(ex.getMessage(), ex);
		}
		return directories;

	}
}