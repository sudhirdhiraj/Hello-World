package com.agile.cah.eit.plm.interfaceutil;

/**
 * Description : Constants file for Interface properties
 * 
 * @author rasmi.raghavan
 * 
 * 
 * @Created : Apr 15, 2018
 * 
 *          Added for CAH Agile Release 7.0
 */
public class InterfaceConstants {

	public static final String INTERFACE_PROPERTIES_FILE_NAME = "BPCSInterfaceConfig";
	public static final String VASTERA_JMS_PROPERTIES_FILE_NAME = "VasteraJMS";
	public static final String BPCS_JMS_PROPERTIES_FILE_NAME = "BpcsJMS";

	public static final String CANONICAL_XSLT = "ECO_Canonical_XSLT";
	public static final String BPCS_XSLT = "BPCS_XSLT";
	public static final String FOLDER_PATH = "InterfaceFolderPath";
	public static final String ERROR_FLDR = "ErrorFolder";
	public static final String OUTPUT_FLDR = "OutPutXMLFolder";
	public static final String INPUT_FLDR = "InputFolder";
	public static final String ARCHIVE_FLDR = "ArchiveFolder";

	public static final String FROM_EMAIL = "FromEMailID";
	public static final String TO_EMAIL = "ToEMailID";
	public static final String MAIL_SERVER = "MailServer";

	public static final String SELECTED_OBJECT_TYPE = "/AgileData/AutomatedTransferOrders/SelectedObjects/Type";
	public static final String SELECTED_OBJECT_NUMBER = "/AgileData/AutomatedTransferOrders/SelectedObjects/NameNumber";
	public static final String ECO_SITE_CODE = "/AgileData/ChangeOrders/AffectedItems[1]/Sites";
	public static final String MCO_SITE_CODE = "/AgileData/ManufacturerOrders/AffectedItems[1]/Sites";
	public static final String SCO_SITE_CODE = "/AgileData/SiteChangeOrders/AffectedItems[1]/Sites";
	public static final String ATO_NUMBER = "/AgileData/AutomatedTransferOrders/CoverPage/AtoNumber";

	// Vastera
	public static final String VASTERA_SITES = "Vastera_Sites";
	public static final String MQ_Q_MANAGER = "QueueManager";
	public static final String MQ_CHANNEL = "Channel";
	public static final String MQ_HOST_NAME = "HostName";
	public static final String MQ_PORT = "Port";
	public static final String MQ_TOPIC_STRING = "TopicString";
	public static final String MQ_TOPIC_OBJECT = "TopicObject";
	public static final String QUEUE_NAME = "QueueName";
	public static final String MQ_EMAIL_ADDRESS = "MQemailaddress";
	public static final String AGILE_SUPPORT_EMAIL_ADDRESS = "AgileSupportemailaddress";
	public static final String VASTERA_EMAIL_ADDRESS = "Vasteraemailaddress";
	public static final String ERROR_MAIL_SUBJECT = "ErroMailSubject";

	// BPCS
	public static final String BPCS_SITES = "BPCS_Sites";
	public static final String BPCS_EMAIL_ADDRESS = "BPCSemailaddress";

}
