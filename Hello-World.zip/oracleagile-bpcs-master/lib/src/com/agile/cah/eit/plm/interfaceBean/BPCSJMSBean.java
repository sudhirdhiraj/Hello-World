package com.agile.cah.eit.plm.interfaceBean;

import java.util.HashMap;

/**
 * Description : Bean class to hold JMS and email properties for BPCS system
 * 
 * @author rasmi.raghavan
 * @version 1.0
 * 
 * @Created : Apr 15, 2018
 * 
 *          Added for CAH Agile Release 7.0
 */
public class BPCSJMSBean {

	private String bpcs_Sites;
	private String queueManager;
	private String channel;
	private String hostname;
	private String mqPort;
	private HashMap<String, String> queueMap = new HashMap<String, String>();

	private String mqEmailAddress;
	private String agileSupporteMailAddress;
	private String bpcsEmailAddress;
	private String mailSubject;
	
	private String keystore;
	
	private String SSL_CIPHER_SUITE_PROPERTY;
	public String getSSL_CIPHER_SUITE_PROPERTY() {
		return SSL_CIPHER_SUITE_PROPERTY;
	}

	public void setSSL_CIPHER_SUITE_PROPERTY(String sSL_CIPHER_SUITE_PROPERTY) {
		SSL_CIPHER_SUITE_PROPERTY = sSL_CIPHER_SUITE_PROPERTY;
	}

	public String getKeystore() {
		return keystore;
	}

	public void setKeystore(String keystore) {
		this.keystore = keystore;
	}

	public String getKeystorepwd() {
		return keystorepwd;
	}

	public void setKeystorepwd(String keystorepwd) {
		this.keystorepwd = keystorepwd;
	}

	public String getTruststore() {
		return truststore;
	}

	public void setTruststore(String truststore) {
		this.truststore = truststore;
	}

	public String getTruststorepwd() {
		return truststorepwd;
	}

	public void setTruststorepwd(String truststorepwd) {
		this.truststorepwd = truststorepwd;
	}

	private String keystorepwd;
	private String truststore;
	private String truststorepwd;

	public String getBpcs_Sites() {
		return bpcs_Sites;
	}

	public void setBpcs_Sites(String bpcs_Sites) {
		this.bpcs_Sites = bpcs_Sites;
	}

	public String getQueueManager() {
		return queueManager;
	}

	public void setQueueManager(String queueManager) {
		this.queueManager = queueManager;
	}

	public String getChannel() {
		return channel;
	}

	public void setChannel(String channel) {
		this.channel = channel;
	}

	public String getMqEmailAddress() {
		return mqEmailAddress;
	}

	public void setMqEmailAddress(String mqEmailAddress) {
		this.mqEmailAddress = mqEmailAddress;
	}

	public String getAgileSupporteMailAddress() {
		return agileSupporteMailAddress;
	}

	public void setAgileSupporteMailAddress(String agileSupporteMailAddress) {
		this.agileSupporteMailAddress = agileSupporteMailAddress;
	}

	public String getBpcsEmailAddress() {
		return bpcsEmailAddress;
	}

	public void setBpcsEmailAddress(String bpcsEmailAddress) {
		this.bpcsEmailAddress = bpcsEmailAddress;
	}

	public HashMap<String, String> getQueueMap() {
		return queueMap;
	}

	public void setQueueMap(HashMap<String, String> queueMap) {
		this.queueMap = queueMap;
	}

	public String getHostname() {
		return hostname;
	}

	public void setHostname(String hostname) {
		this.hostname = hostname;
	}

	public String getMqPort() {
		return mqPort;
	}

	public void setMqPort(String mqPort) {
		this.mqPort = mqPort;
	}

	public String getMailSubject() {
		return mailSubject;
	}

	public void setMailSubject(String mailSubject) {
		this.mailSubject = mailSubject;
	}

}
