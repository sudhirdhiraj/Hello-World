package com.agile.cah.eit.plm.xmltools;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.FactoryConfigurationError;
import javax.xml.parsers.ParserConfigurationException;
import org.xml.sax.SAXException;
import org.xml.sax.SAXParseException;
import org.w3c.dom.Document;
import org.w3c.dom.DOMException;

// For write operation
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamSource;
import javax.xml.transform.stream.StreamResult;
import java.io.*;


public class XMLConverterTest {

	static Document document;
	static Document document1;

    public static void main(String[] argv) {
        
        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
      
        try {
            /*File stylesheet = new File("config/AxmlToECOCanonicalMap.xslt");
            File datafile = new File("config/ECO-EC083014-agile.xml");
            OutputStream op = new FileOutputStream("config/ECOCanonicalXML.xml");

            System.out.println("xml file"+ datafile.getAbsolutePath());
            System.out.println("Present working dir"+System.getProperty("user.dir"));
            DocumentBuilder builder = factory.newDocumentBuilder();
            document = builder.parse(datafile);

            // Use a Transformer for output
            TransformerFactory tFactory = javax.xml.transform.TransformerFactory.newInstance();
            //TransformerFactory tFactory = new net.sf.saxon.TransformerFactoryImpl();
            StreamSource stylesource = new StreamSource(stylesheet);
            Transformer transformer = tFactory.newTransformer(stylesource);

            DOMSource source = new DOMSource(document);
            System.out.println("Output XML :");
            StreamResult result = new StreamResult(op);
            transformer.transform(source, result);
            
            System.out.println("Transformation1 complete");  */
          
        	System.setProperty("org.apache.xalan.extensions.bsf.BSFManager","org.apache.bsf.BSFManager");
            File stylesheet1 = new File("config/EcoCanonicalToBPCSMapWOJS.xslt");
            File datafile1 = new File("config/ECOCanonicalXML.xml");
            //File datafile1 = new File("config/OutputNXML.xml");
            OutputStream op1 = new FileOutputStream("config/BPCSXml.xml");

            System.out.println("xml file"+ datafile1.getAbsolutePath());
            System.out.println("Present working dir"+System.getProperty("user.dir"));
            DocumentBuilder builder1 = factory.newDocumentBuilder();
            document1 = builder1.parse(datafile1);

            // Use a Transformer for output
            //TransformerFactory tFactory1 = new net.sf.saxon.TransformerFactoryImpl();
            TransformerFactory tFactory1 = javax.xml.transform.TransformerFactory.newInstance();
            StreamSource stylesource1 = new StreamSource(stylesheet1);
            Transformer transformer1 = tFactory1.newTransformer(stylesource1);

            DOMSource source1 = new DOMSource(document1);
            System.out.println("Output XML :");
            StreamResult result1 = new StreamResult(op1);
            transformer1.transform(source1, result1);
            
            System.out.println("Transformation2 complete");
            
        } catch (TransformerConfigurationException tce) {
            
            System.out.println("\n** Transformer Factory error");
            System.out.println("   " + tce.getMessage());

            Throwable x = tce;
            if (tce.getException() != null) {
                x = tce.getException();
            }

            x.printStackTrace();
        } catch (TransformerException te) {
            
            System.out.println("\n** Transformation error");
            System.out.println("   " + te.getMessage());

            Throwable x = te;
            if (te.getException() != null) {
                x = te.getException();
            }

            x.printStackTrace();
        } catch (SAXException sxe) {
       
            Exception x = sxe;
            if (sxe.getException() != null) {
                x = sxe.getException();
            }

            x.printStackTrace();
        } catch (ParserConfigurationException pce) {            
            pce.printStackTrace();
        } catch (IOException ioe) {            
            ioe.printStackTrace();
        }catch (Exception e){
        	e.printStackTrace();
        }
        
    } // main
}


