package com.agile.cah.eit.plm.xmltools;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;

import org.xml.sax.SAXException;

import com.agile.cah.eit.plm.interfaceutil.FileUtil;

/**
 * Description : Class to convert canonical XML to BPCS XML
 * 
 * @author rasmi.raghavan
 * @version 1.0
 * 
 * @Created : Apr 15, 2018
 * 
 *          Added for CAH Agile Release 7.0
 */
public class BPCSXmlConverter extends XMLConverter {

	static org.apache.logging.log4j.Logger log;

	static {
		log = org.apache.logging.log4j.LogManager.getLogger(FileUtil.class);
	}

	public BPCSXmlConverter(String xslFileName, String dataFileName) {
		super(xslFileName, dataFileName);
	}

	/**
	 * Method to transfor canonical xml to BPCS XML
	 * 
	 * @param opXmlName
	 *            output xml file name
	 * @param xslFileName
	 *            xsl file name
	 * @return boolean
	 */
	public boolean transformXML(String opXmlName, String xslFileName) {
		// TODO Auto-generated method stub

		try {
			log.info("BPCS transformation started for xml file "
					+ dataFile.getAbsolutePath());
			OutputStream op = new FileOutputStream(opXmlName);
			DocumentBuilder builder = factory.newDocumentBuilder();
			document = builder.parse(dataFile);

			StreamSource stylesource = new StreamSource(styleSheet);
			Transformer transformer = transFactory.newTransformer(stylesource);

			DOMSource source = new DOMSource(document);
			StreamResult result = new StreamResult(op);
			transformer.transform(source, result);

			op.flush();
			op.close();
			log.info("BPCS Transformation complete");
			return true;
		} catch (TransformerConfigurationException transConfigEx) {

			log.error("Exception : " + transConfigEx.getMessage());

		} catch (TransformerException transEx) {

			log.error("Exception : " + transEx.getMessage());

		} catch (IOException ioEx) {

			log.error("Exception : " + ioEx.getMessage());

		} catch (ParserConfigurationException parserConfigEx) {

			log.error("Exception : " + parserConfigEx.getMessage());

		} catch (SAXException saxEx) {

			log.error("Exception : " + saxEx.getMessage());

		} catch (Exception ex) {

			log.error("Exception : " + ex.getMessage());

		}

		return false;
	}

}
