package com.agile.cah.eit.plm.interfaceutil;

import java.util.HashMap;
import java.util.ResourceBundle;
import java.util.StringTokenizer;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.agile.cah.eit.plm.interfaceBean.BPCSJMSBean;
import com.agile.cah.eit.plm.interfaceBean.PropertiesBean;
import com.agile.cah.eit.plm.interfaceBean.VasteraJMSBean;

/**
 * Description : Java class to load the interface properties file
 * 
 * @author rasmi.raghavan
 * @version 1.0
 * 
 * @Created : Apr 15, 2018
 * 
 *          Added for CAH Agile Release 7.0
 */
public class PropertiesLoader {

	PropertiesBean propBean = null;
	VasteraJMSBean vasteraBean = null;
	BPCSJMSBean bpcsBean = null;

	/**
	 * Constructor
	 */
	public PropertiesLoader() {
		propBean = new PropertiesBean();
		vasteraBean = new VasteraJMSBean();
		bpcsBean = new BPCSJMSBean();
	}

	static Logger log;
	static {
		log = LogManager.getLogger(PropertiesLoader.class);

	}

	ResourceBundle resourceBundle = null;

	/**
	 * Method to load the general Interface properties file
	 * 
	 * @param propFile
	 *            Interface Properties file name
	 * @return PropertiesBean
	 * @throws InterfaceException
	 */
	public PropertiesBean loadInterfacePropFile(String propFile)
			throws InterfaceException {
		ResourceBundle resourceBundle = ResourceBundle.getBundle(propFile);
		if (resourceBundle != null) {
			propBean = loadInterfaceProperties(resourceBundle);
		} else {
			log.error("Error loading Interface properties file");
			throw new InterfaceException(
					"Error loading Interface properties file");
		}
		return propBean;
	}

	/**
	 * Method to get the values for each property and set the values in
	 * PropertiesBean
	 * 
	 * @param resBundle
	 *            Resource Bundle for Interface properties
	 * @return PropertiesBean
	 * @throws InterfaceException
	 */
	public PropertiesBean loadInterfaceProperties(ResourceBundle resBundle)
			throws InterfaceException {
		canonicalXSLT = getPropValue(resBundle,
				InterfaceConstants.CANONICAL_XSLT);
		propBean.setCanonicalXSLT(canonicalXSLT);
		bpcsXSLT = getPropValue(resBundle, InterfaceConstants.BPCS_XSLT);
		propBean.setBpcsXSLT(bpcsXSLT);
		folderPath = getPropValue(resBundle, InterfaceConstants.FOLDER_PATH);
		propBean.setFolderPath(folderPath);
		errorFolder = getPropValue(resBundle, InterfaceConstants.ERROR_FLDR);
		propBean.setErrorFolder(errorFolder);
		canonicalFolder = getPropValue(resBundle,
				InterfaceConstants.OUTPUT_FLDR);
		propBean.setOutputFolder(canonicalFolder);
		bpcsFolder = getPropValue(resBundle, InterfaceConstants.INPUT_FLDR);
		propBean.setInputFolder(bpcsFolder);
		archiveFolder = getPropValue(resBundle, InterfaceConstants.ARCHIVE_FLDR);
		propBean.setArchiveFolder(archiveFolder);
		fromEMailID = getPropValue(resBundle, InterfaceConstants.FROM_EMAIL);
		propBean.setFromEMailID(fromEMailID);
		toEMailID = getPropValue(resBundle, InterfaceConstants.TO_EMAIL);
		propBean.setToEMailID(toEMailID);
		mailServer = getPropValue(resBundle, InterfaceConstants.MAIL_SERVER);
		propBean.setMailServer(mailServer);
		vastera_Sites = getPropValue(resBundle,
				InterfaceConstants.VASTERA_SITES);
		propBean.setVastera_Sites(vastera_Sites);
		return propBean;

	}

	/**
	 * Method to load the Vastera JMS properties file
	 * 
	 * @param propFile
	 *            Vastera Properties file name
	 * @return VasteraJMSBean
	 * @throws InterfaceException
	 */
	public VasteraJMSBean loadVasteraPropFile(String propFile)
			throws InterfaceException {
		ResourceBundle resourceBundle = ResourceBundle.getBundle(propFile);
		if (resourceBundle != null) {
			vasteraBean = loadVasteraProperties(resourceBundle);
		} else {
			log.error("Error loading Vastera JMS properties file");
			throw new InterfaceException(
					"Error loading Vastera JMS properties file");
		}
		return vasteraBean;
	}

	/**
	 * Method to get the values for each property and set the values in
	 * VasteraJMSBean
	 * 
	 * @param resBundle
	 *            Resource Bundle for Vastera properties
	 * @return VasteraJMSBean
	 * @throws InterfaceException
	 */
	public VasteraJMSBean loadVasteraProperties(ResourceBundle resBundle)
			throws InterfaceException {

		vastera_Sites = getPropValue(resBundle,
				InterfaceConstants.VASTERA_SITES);
		vasteraBean.setVastera_Sites(vastera_Sites);

		queueManager = getPropValue(resBundle, InterfaceConstants.MQ_Q_MANAGER);
		vasteraBean.setQueueManager(queueManager);

		channel = getPropValue(resBundle, InterfaceConstants.MQ_CHANNEL);
		vasteraBean.setChannel(channel);

		hostname = getPropValue(resBundle, InterfaceConstants.MQ_HOST_NAME);
		vasteraBean.setHostname(hostname);

		mqPort = getPropValue(resBundle, InterfaceConstants.MQ_PORT);
		vasteraBean.setMqPort(mqPort);

		 mqkeystore = getPropValue(resBundle, "keyStore");
		 vasteraBean.setKeystore(mqkeystore); 
		 
		 mqkeystorepwd = getPropValue(resBundle, "keyStorepwd"); 
		 vasteraBean.setKeystorepwd(mqkeystorepwd);
		 
		 mqtrustkey =getPropValue(resBundle, "trustStore"); 
		 vasteraBean.setTruststore(mqtrustkey);
		 
		 mqtrustpwd = getPropValue(resBundle, "trustStorepwd");
		 vasteraBean.setTruststorepwd(mqtrustpwd);
		
		 mqsslcipher = getPropValue(resBundle, "sslcipher");
		 vasteraBean.setSSL_CIPHER_SUITE_PROPERTY(mqsslcipher);
		 
		topicString = getPropValue(resBundle,
				InterfaceConstants.MQ_TOPIC_STRING);
		vasteraBean.setTopicString(topicString);

		mqEmailAddress = getPropValue(resBundle,
				InterfaceConstants.MQ_EMAIL_ADDRESS);
		vasteraBean.setMqEMailAddress(mqEmailAddress);

		agileSupportEmailAddress = getPropValue(resBundle,
				InterfaceConstants.AGILE_SUPPORT_EMAIL_ADDRESS);
		vasteraBean.setAgileSupporteMailAddress(agileSupportEmailAddress);

		vasteraEmailAddress = getPropValue(resBundle,
				InterfaceConstants.VASTERA_EMAIL_ADDRESS);
		vasteraBean.setVasteraeMailAddress(vasteraEmailAddress);

		vasteraMailSubject = getPropValue(resBundle,
				InterfaceConstants.ERROR_MAIL_SUBJECT);
		vasteraBean.setMailSubject(vasteraMailSubject);
		return vasteraBean;

	}

	/**
	 * Method to load the BPCS JMS properties file
	 * 
	 * @param propFile
	 *            BPCS Properties file name
	 * @return BPCSJMSBean
	 * @throws InterfaceException
	 */
	public BPCSJMSBean loadBPCSPropFile(String propFile)
			throws InterfaceException {
		ResourceBundle resourceBundle = ResourceBundle.getBundle(propFile);
		if (resourceBundle != null) {
			bpcsBean = loadBPCSProperties(resourceBundle);
		} else {
			log.error("Error loading BPCS JMS properties file");
			throw new InterfaceException(
					"Error loading BPCS JMS properties file");
		}
		return bpcsBean;
	}

	/**
	 * Method to get the values for each property and set the values in
	 * BPCSJMSBean
	 * 
	 * @param resBundle
	 *            Resource Bundle for BPCS properties
	 * @return BPCSJMSBean
	 * @throws InterfaceException
	 */
	public BPCSJMSBean loadBPCSProperties(ResourceBundle resBundle)
			throws InterfaceException {

		String topicStr = "";
		HashMap<String, String> queueMap = new HashMap<String, String>();
		bpcs_Sites = getPropValue(resBundle, InterfaceConstants.BPCS_SITES);
		bpcsBean.setBpcs_Sites(bpcs_Sites);

		queueManager = getPropValue(resBundle, InterfaceConstants.MQ_Q_MANAGER);
		bpcsBean.setQueueManager(queueManager);

		channel = getPropValue(resBundle, InterfaceConstants.MQ_CHANNEL);
		bpcsBean.setChannel(channel);

		hostname = getPropValue(resBundle, InterfaceConstants.MQ_HOST_NAME);
		bpcsBean.setHostname(hostname);

		mqPort = getPropValue(resBundle, InterfaceConstants.MQ_PORT);
		bpcsBean.setMqPort(mqPort);

		
		 mqkeystore = getPropValue(resBundle, "keyStore");
		 bpcsBean.setKeystore(mqkeystore); 
		 
		 mqkeystorepwd = getPropValue(resBundle, "keyStorepwd"); 
		 bpcsBean.setKeystorepwd(mqkeystorepwd);
		 
		 mqtrustkey =getPropValue(resBundle, "trustStore"); 
		 bpcsBean.setTruststore(mqtrustkey);
		 
		 mqtrustpwd = getPropValue(resBundle, "trustStorepwd");
		 bpcsBean.setTruststorepwd(mqtrustpwd);
		
		 mqsslcipher = getPropValue(resBundle, "sslcipher");
		 bpcsBean.setSSL_CIPHER_SUITE_PROPERTY(mqsslcipher);
		
		StringTokenizer siteToken = new StringTokenizer(bpcs_Sites, ";");
		String siteID = "";
		while (siteToken.hasMoreTokens()) {

			siteID = siteToken.nextToken();
			topicStr = getPropValue(resBundle, siteID);
			queueMap.put(siteID, topicStr);
		}
		log.info("Topic String Hashmap = " + queueMap);
		bpcsBean.setQueueMap(queueMap);

		mqEmailAddress = getPropValue(resBundle,
				InterfaceConstants.MQ_EMAIL_ADDRESS);
		bpcsBean.setMqEmailAddress(mqEmailAddress);

		agileSupportEmailAddress = getPropValue(resBundle,
				InterfaceConstants.AGILE_SUPPORT_EMAIL_ADDRESS);
		bpcsBean.setAgileSupporteMailAddress(agileSupportEmailAddress);

		bpcsEmailAddress = getPropValue(resBundle,
				InterfaceConstants.BPCS_EMAIL_ADDRESS);
		bpcsBean.setBpcsEmailAddress(bpcsEmailAddress);

		bpcsMailSubject = getPropValue(resBundle,
				InterfaceConstants.ERROR_MAIL_SUBJECT);
		bpcsBean.setMailSubject(bpcsMailSubject);
		return bpcsBean;

	}

	/**
	 * Method to get the property value for each properties
	 * 
	 * @param resBundle
	 *            Resource Bundle for properties file
	 * @param key
	 *            Property name
	 * @return Property value
	 * @throws InterfaceException
	 */
	public String getPropValue(ResourceBundle resBundle, String key)
			throws InterfaceException {
		try {
			String propVal = null;
			propVal = resBundle.getString(key);
			return propVal != null ? propVal.trim() : null;
		} catch (Exception ex) {
			throw new InterfaceException("Error reading value for key: " + key,
					ex);
		}

	}

	public String agile_Sites;
	public String canonicalXSLT;
	public String bpcsXSLT;
	public String folderPath;

	public String errorFolder;
	public String canonicalFolder;
	public String bpcsFolder;
	public String archiveFolder;
	public String fromEMailID;
	public String toEMailID;
	public String mailServer;

	// Vastera JMS properties
	public String vastera_Sites;
	public String vasteraMailSubject;
	public String bpcsMailSubject;
	public String queueManager;
	public String channel;
	public String hostname;
	public String mqPort;
	public String topicString;
	public String queueName;
	public String mqEmailAddress;
	public String agileSupportEmailAddress;
	public String vasteraEmailAddress;
	public String mqkeystore;
	public String mqkeystorepwd;
	public String mqtrustkey;
	public String  mqtrustpwd;
	public String mqsslcipher;

	// BPCS JMS
	public String bpcs_Sites;
	public String siteID;
	// public String AgileMQemailaddress;
	public String agileSupportemailAddress;
	public String bpcsEmailAddress;

}
