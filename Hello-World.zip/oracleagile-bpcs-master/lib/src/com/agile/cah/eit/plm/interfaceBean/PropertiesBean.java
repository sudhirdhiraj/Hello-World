package com.agile.cah.eit.plm.interfaceBean;

/**
 * Description : Bean class to hold general interface properties
 * 
 * @author rasmi.raghavan
 * @version 1.0
 * 
 * @Created : Apr 15, 2018
 * 
 *          Added for CAH Agile Release 7.0
 */
public class PropertiesBean {

	private static String canonicalXSLT;
	private static String bpcsXSLT;
	private static String folderPath;
	private static String errorFolder;
	private static String outputFolder;
	private static String inputFolder;
	private static String archiveFolder;
	private static String fromEMailID;
	private static String toEMailID;
	private static String mailServer;
	private String vastera_Sites;

	public String getCanonicalXSLT() {
		return canonicalXSLT;
	}

	public void setCanonicalXSLT(String canonicalXSLT) {
		PropertiesBean.canonicalXSLT = canonicalXSLT;
	}

	public String getBpcsXSLT() {
		return bpcsXSLT;
	}

	public void setBpcsXSLT(String bpcsXSLT) {
		PropertiesBean.bpcsXSLT = bpcsXSLT;
	}

	public String getFolderPath() {
		return folderPath;
	}

	public void setFolderPath(String folderPath) {
		PropertiesBean.folderPath = folderPath;
	}

	public String getErrorFolder() {
		return errorFolder;
	}

	public void setErrorFolder(String errorFolder) {
		PropertiesBean.errorFolder = errorFolder;
	}

	public String getOutputFolder() {
		return outputFolder;
	}

	public void setOutputFolder(String outputFolder) {
		PropertiesBean.outputFolder = outputFolder;
	}

	public String getInputFolder() {
		return inputFolder;
	}

	public void setInputFolder(String inputFolder) {
		PropertiesBean.inputFolder = inputFolder;
	}

	public String getArchiveFolder() {
		return archiveFolder;
	}

	public void setArchiveFolder(String archiveFolder) {
		PropertiesBean.archiveFolder = archiveFolder;
	}

	public String getFromEMailID() {
		return fromEMailID;
	}

	public void setFromEMailID(String fromEMailID) {
		PropertiesBean.fromEMailID = fromEMailID;
	}

	public String getToEMailID() {
		return toEMailID;
	}

	public void setToEMailID(String toEMailID) {
		PropertiesBean.toEMailID = toEMailID;
	}

	public String getMailServer() {
		return mailServer;
	}

	public void setMailServer(String mailServer) {
		PropertiesBean.mailServer = mailServer;
	}

	public String getVastera_Sites() {
		return vastera_Sites;
	}

	public void setVastera_Sites(String vastera_Sites) {
		this.vastera_Sites = vastera_Sites;
	}

}
