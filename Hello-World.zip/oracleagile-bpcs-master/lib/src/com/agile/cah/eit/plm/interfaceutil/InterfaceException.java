package com.agile.cah.eit.plm.interfaceutil;

/**
 * Description : Exception class for Interface to handle specific exception
 * thrown by the Interface program
 * 
 * @author rasmi.raghavan
 * @version 1.0
 * 
 * @Created : Apr 15, 2018
 * 
 *          Added for CAH Agile Release 7.0
 */

public class InterfaceException extends Exception {

	private static final long serialVersionUID = 1L;

	public InterfaceException(String errMsg) {
		super(errMsg);
	}

	public InterfaceException(String errMsg, Throwable cause) {
		super(errMsg, cause);
	}

}
