package com.agile.cah.eit.plm.integrator;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.StringTokenizer;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.w3c.dom.Document;

import com.agile.cah.eit.plm.interfaceBean.BPCSJMSBean;
import com.agile.cah.eit.plm.interfaceBean.PropertiesBean;
import com.agile.cah.eit.plm.interfaceBean.VasteraJMSBean;
import com.agile.cah.eit.plm.interfaceutil.EMailUtil;
import com.agile.cah.eit.plm.interfaceutil.FileUtil;
import com.agile.cah.eit.plm.interfaceutil.InterfaceConstants;
import com.agile.cah.eit.plm.interfaceutil.InterfaceException;
import com.agile.cah.eit.plm.interfaceutil.MQPublisher;
import com.agile.cah.eit.plm.interfaceutil.PropertiesLoader;
import com.agile.cah.eit.plm.interfaceutil.XMLUtil;
import com.ibm.mq.MQException;
import com.ibm.mq.MQMessage;
import com.ibm.mq.MQPutMessageOptions;
import com.ibm.mq.MQQueueManager;
import com.ibm.mq.MQTopic;
import com.ibm.mq.constants.CMQC;

/**
 * Description : Main class to send the payload to BPCS and Vastera Queues for
 * each sites
 * 
 * @author rasmi.raghavan
 * @version 1.0 *
 * 
 * @Created : Apr 15, 2018
 * 
 *          Added for CAH Agile Release 7.0
 */
public class SendPayLoadToJMS {

	static Logger log;
	static {
		log = LogManager.getLogger(SendPayLoadToJMS.class);

	}

	static PropertiesBean propBean = null;
	static VasteraJMSBean vasteraBean = null;
	static BPCSJMSBean bpcsBean = null;
	static String agileMailID = null;
	static String mqMailID = null;
	static String bpcsMailID = null;
	static String vasteraMailID = null;
	static String bpcsErrSub = "";
	static String vasteraErrSub = "";

	public static void main(String[] args) {

		log.info("SendPayLoadToJMS started at - "
				+ Calendar.getInstance().getTime());
		SendPayLoadToJMS sendData = new SendPayLoadToJMS();
		PropertiesLoader propLoader = new PropertiesLoader();
		FileUtil fUtil = new FileUtil();
		MQPublisher mqUtil = new MQPublisher();
		EMailUtil mailUtil = new EMailUtil();

		MQTopic bpcsPublisher = null;
		MQTopic vasteraPublisher = null;
		Hashtable<String, Object> bpcsMQht = null;
		Hashtable<String, Object> vasteraMQht = null;
		MQQueueManager _qMgr = null;
		boolean bpcsErrorMailSent = false;
		boolean vasteraErrorMailSent = false;

		try {
			propBean = propLoader
					.loadInterfacePropFile(InterfaceConstants.INTERFACE_PROPERTIES_FILE_NAME);
			vasteraBean = propLoader
					.loadVasteraPropFile(InterfaceConstants.VASTERA_JMS_PROPERTIES_FILE_NAME);
			bpcsBean = propLoader
					.loadBPCSPropFile(InterfaceConstants.BPCS_JMS_PROPERTIES_FILE_NAME);

			agileMailID = bpcsBean.getAgileSupporteMailAddress();
			mqMailID = bpcsBean.getMqEmailAddress();
			bpcsMailID = bpcsBean.getBpcsEmailAddress();
			vasteraMailID = vasteraBean.getVasteraeMailAddress();

			if (!(bpcsMailID.endsWith(",")))
				bpcsMailID = bpcsMailID + ",";
			if (!(agileMailID.endsWith(",")))
				agileMailID = agileMailID + ",";
			if (!(mqMailID.endsWith(",")))
				mqMailID = mqMailID + ",";
			if (!(vasteraMailID.endsWith(",")))
				vasteraMailID = vasteraMailID + ",";

			String axmlFolderForSite = propBean.getFolderPath();
			File[] files = fUtil.getDirectories(axmlFolderForSite);
			String vasteraSites = vasteraBean.getVastera_Sites();
			String bpcsSites = bpcsBean.getBpcs_Sites();
			HashMap<String, String> queueMap = bpcsBean.getQueueMap();
			bpcsMQht = mqUtil.initBpcsContext(bpcsBean);
			vasteraMQht = mqUtil.initVasteraContext(vasteraBean);

			// Get BPCS queue manager
			_qMgr = mqUtil.getBpcsMQConnection(bpcsMQht, bpcsBean);

			// Get vastera publisher using connection parameters
			vasteraPublisher = mqUtil.getVasteraMQConnection(vasteraMQht,
					vasteraBean);

			// Iterate through each site folder
			for (File file : files) {
				String siteName = file.getName();
				String bpcsTopicString = queueMap.get(siteName);
				log.info("Processing files for Site : " + siteName);
				String siteAxmlFldr = axmlFolderForSite + "/" + siteName;
				String opFldrPath = siteAxmlFldr + "/"
						+ propBean.getOutputFolder();
				String archiveFldrPath = siteAxmlFldr + "/"
						+ propBean.getArchiveFolder();
				String errorFldrPath = siteAxmlFldr + "/"
						+ propBean.getErrorFolder();
				boolean isBpcsSite = false;
				boolean isVasteraSite = false;

				// Check if site is BPCS site
				isBpcsSite = sendData.checkSiteInList(bpcsSites, siteName);

				// Check if site is vastera site
				isVasteraSite = sendData
						.checkSiteInList(vasteraSites, siteName);
				boolean hasBPCSXML = false;
				boolean hasVasteraXML = false;

				// Check if the output folder has BPCS & Vastera xml files
				hasBPCSXML = sendData.checkHasBPCSXML(opFldrPath);
				hasVasteraXML = sendData.checkHasVasteraXML(opFldrPath);

				/*
				 * try { if (isBpcsSite && isVasteraSite) {
				 * sendData.replicateBPCSXml(opFldrPath, fUtil); } } catch
				 * (InterfaceException iEx) { log.error(iEx.getMessage());
				 * iEx.printStackTrace(); }
				 */
				File outDir = new File(opFldrPath);
				if (outDir.isDirectory() && (outDir.list().length > 0)) {

					// Send error email if unable to establish bpcs connection
					if (_qMgr == null && !bpcsErrorMailSent && hasBPCSXML) {

						String toEMailIDs = bpcsMailID + agileMailID + mqMailID;
						try {
							mailUtil.sendMQErrorMail(toEMailIDs,
									propBean.getFromEMailID(),
									propBean.getMailServer(),
									MQPublisher.bpcs_error_message,
									bpcsBean.getQueueManager(),
									bpcsBean.getMailSubject());
							bpcsErrorMailSent = true;
						} catch (InterfaceException iEx) {
							log.error(iEx.getMessage());
							iEx.printStackTrace();
						}
						MQPublisher.bpcs_error_message = "";
					} else if (isBpcsSite && (_qMgr != null)) {

						// Publish the all bpcs xml file to bpcs site
						bpcsPublisher = sendData.SendToBPCSQueue(
								archiveFldrPath, errorFldrPath, opFldrPath,
								fUtil, _qMgr, bpcsTopicString, siteName);
						try {
							if (bpcsPublisher != null)

								// close bpcs connection for the site
								bpcsPublisher.close();
						} catch (MQException e) {
							log.error("Unable to close the bpcsPublisher : MQException CC="
									+ e.completionCode
									+ " : RC="
									+ e.reasonCode);
						}

					}
					log.info("vasteraPublisher ==== " + vasteraPublisher);
					log.info("!vasteraErrorMailSent ===== "
							+ vasteraErrorMailSent);
					log.info("hasVasteraXML ====" + hasVasteraXML);

					// Send error email to vastera team if unable to get vastera
					// connection
					if (vasteraPublisher == null && !vasteraErrorMailSent
							&& hasVasteraXML) {
						log.info("Vastera publisher is null, so sending email");
						String toEMailIDs = vasteraMailID + agileMailID
								+ mqMailID;
						try {
							mailUtil.sendMQErrorMail(toEMailIDs,
									propBean.getFromEMailID(),
									propBean.getMailServer(),
									MQPublisher.vastera_error_message,
									vasteraBean.getQueueManager(),
									vasteraBean.getMailSubject());
							vasteraErrorMailSent = true;
							log.info("Vastera error email sent");
						} catch (InterfaceException iEx) {
							log.error(iEx.getMessage());
							iEx.printStackTrace();
						}
						MQPublisher.vastera_error_message = "";
					} else if (isVasteraSite && (vasteraPublisher != null)) {
						// Send vastera xml file to vastera site
						sendData.sendToVasteraQueue(archiveFldrPath,
								errorFldrPath, opFldrPath, vasteraPublisher,
								fUtil);
					}
				}
			}

		} catch (Exception ex) {
			log.error("Exception : " + ex.getMessage());
			ex.printStackTrace();
		} finally {
			try {
				// close vastera connection
				if (vasteraPublisher != null)
					vasteraPublisher.close();
			} catch (MQException e) {
				log.error("Error closing vastera publisher connection:");
				log.error("MQException CC=" + e.completionCode + " : RC="
						+ e.reasonCode);
			}
			try {
				if (_qMgr != null)
					_qMgr.disconnect();
			} catch (MQException e) {
				log.error("Error disconnecting BPCS Queue manager");
				log.error("MQException CC=" + e.completionCode + " : RC="
						+ e.reasonCode);
			}
			try {
				if (MQPublisher._qMgrVastera != null)
					MQPublisher._qMgrVastera.disconnect();
				MQPublisher._qMgrVastera = null;
				// MQPublisher._qMgrVastera.close();
			} catch (MQException e) {
				log.error("Error closing BPCS publisher connection:");
				log.error("MQException CC=" + e.completionCode + " : RC="
						+ e.reasonCode);
			}

		}

	}

	/**
	 * Method to check if the site is listed in the BPCS or Vastera site list
	 * 
	 * @param siteList
	 *            List of BPCS or Vastera sites
	 * @param siteName
	 *            SiteName
	 * @return boolean
	 */
	public boolean checkSiteInList(String siteList, String siteName) {
		StringTokenizer siteToken = new StringTokenizer(siteList, ";");
		while (siteToken.hasMoreTokens()) {
			if (siteToken.nextToken().equals(siteName))
				return true;
		}
		return false;
	}

	/**
	 * Method to post all the bpcs xml to BPCS Message Queue
	 * 
	 * @param archiveFldr
	 *            Archive folder path
	 * @param errorFldr
	 *            Error folder path
	 * @param siteFldr
	 *            Site folder path
	 * @param fUtil
	 *            FileUtill object
	 * @param _qMgr
	 *            BPCS Queue manager
	 * @param topicStr
	 *            BPCS topic string for the site
	 * @param siteName
	 *            Site Name
	 * @return MQTopic
	 */
	public MQTopic SendToBPCSQueue(String archiveFldr, String errorFldr,
			String siteFldr, FileUtil fUtil, MQQueueManager _qMgr,
			String topicStr, String siteName) {

		// Sort files in the folder in chronological order in which they are
		// created
		File[] filesInDir = fUtil.sortFilesNew(siteFldr);
		String bpcsPath = null;
		MQTopic publisher = null;

		log.info("%%%%%%%%%%%%% BPCS Topic String for Site: " + siteName
				+ " = " + topicStr);
		String fileName = null;
		MQPutMessageOptions pmo = new MQPutMessageOptions();

		try {

			// Get BPCS publisher
			publisher = _qMgr.accessTopic(topicStr, "",
					CMQC.MQTOPIC_OPEN_AS_PUBLICATION, CMQC.MQOO_OUTPUT);
			log.info("TopicString opened for BPCS publisher: "
					+ publisher.getName());

		} catch (MQException e) {
			e.printStackTrace();
			log.error("MQException CC=" + e.completionCode + " : RC="
					+ e.reasonCode);
			log.error("Unable to connect to MQ TopicString " + publisher);
			return null;

		}

		// iterate through each BPCS xml file in the site folder and send file
		// to BPCS queue
		for (File bpcsXml : filesInDir) {
			try {
				bpcsPath = bpcsXml.getAbsoluteFile().toString();
				fileName = bpcsPath.substring(bpcsPath.lastIndexOf("/") + 1);
				if (bpcsPath.contains("_Bpcs")) {
					log.info("Publishing BPCS file: " + bpcsPath);
					Document doc = XMLUtil.parseXml(bpcsPath);
					String xmlPayload = XMLUtil.getXmlAsString(doc);
					log.info("XML Payload ************************");
					log.info(xmlPayload);
					log.info("********************************");
					MQMessage mqMsg = new MQMessage();
					// mqMsg.messageId = CMQC.MQMI_NONE;
					// mqMsg.messageId = siteName.getBytes();

					mqMsg.correlationId = CMQC.MQCI_NONE;
					mqMsg.characterSet = 1208;
					mqMsg.format = "MQSTR";
					// mqMsg.
					mqMsg.writeString(xmlPayload);

					// Publish BPCS xml file to bpcs queue
					publisher.put(mqMsg, pmo);
					log.info("File published Successfully ");

					// Move the BPCS xml file to archive folder
					bpcsXml.renameTo(new File(archiveFldr + "/" + fileName));

				}

				// Move canonical file to archive folder
				if (bpcsPath.contains("_Canonical")) {
					bpcsXml.renameTo(new File(archiveFldr + "/" + fileName));
				}
			} catch (Exception ex) {

				// On error or exception scenario move bpcs xml to error folder
				bpcsXml.renameTo(new File(errorFldr + "/" + fileName));
				log.error("Error while publishing file :" + bpcsPath
						+ " to BPCS JMS Queue");
				log.error("Error while publishing file :" + ex);
			}
		}
		return publisher;
	}

	/**
	 * Method to send vastera xml file to vastera site
	 * 
	 * @param archiveFldr
	 *            Archive folder path
	 * @param errorFldr
	 *            Error folder path
	 * @param siteFldr
	 *            Site folder path
	 * @param vasteraPublisher
	 *            MQTopic for vastera queue
	 * @param fUtil
	 *            FileUtill object
	 */
	public void sendToVasteraQueue(String archiveFldr, String errorFldr,
			String siteFldr, MQTopic vasteraPublisher, FileUtil fUtil) {

		// Sort files in the folder in chronological order in which they are
		// created
		File[] filesInDir = fUtil.sortFilesNew(siteFldr);
		String vasteraPath = null;
		String fileName = null;
		MQPutMessageOptions pmo = new MQPutMessageOptions();
		for (File vasteraXml : filesInDir) {
			try {
				vasteraPath = vasteraXml.getAbsoluteFile().toString();
				fileName = vasteraPath
						.substring(vasteraPath.lastIndexOf("/") + 1);
				if (vasteraPath.contains("_Vastera")) {
					log.info("Publishing vastera file: " + vasteraPath);
					Document doc = XMLUtil.parseXml(vasteraPath);
					String xmlPayload = XMLUtil.getXmlAsString(doc);
					MQMessage mqMsg = new MQMessage();
					// mqMsg.messageId = CMQC.MQMI_NONE;
					// mqMsg.correlationId = CMQC.MQCI_NONE;
					mqMsg.characterSet = 1208;
					mqMsg.format = "MQSTR";
					mqMsg.writeString(xmlPayload);

					// Send vastera xml data to vastera queue
					vasteraPublisher.put(mqMsg, pmo);
					log.info("File published Successfully ");

					// Move vastera xml file to archive folder
					vasteraXml.renameTo(new File(archiveFldr + "/" + fileName));
				}
			} catch (Exception ex) {
				// On error or exception scenario move vastera xml to error
				// folder
				vasteraXml.renameTo(new File(errorFldr + "/" + fileName));
				log.error("Error while publishing file :" + vasteraPath
						+ " to Vastera JMS Queue");
			}
		}
	}

	/**
	 * Method to get queue name from queue map
	 * 
	 * @param qMap
	 *            Queue map
	 * @param siteID
	 *            Site name
	 * @return String site name
	 */
	public String getQueueName(HashMap<String, String> qMap, String siteID) {
		return qMap.get(siteID).toString();
	}

	/**
	 * Replicate bpcs xml contents to vastera xml file
	 * 
	 * @param opFldrPath
	 *            Output folder path
	 * @param fUtil
	 *            FileUtil object
	 * @throws InterfaceException
	 */
	public void replicateBPCSXml(String opFldrPath, FileUtil fUtil)
			throws InterfaceException {

		// Sort files in the folder in chronological order in which they are
		// created
		File[] filesInDir = fUtil.sortFiles(opFldrPath);
		File vasteraFile = null;
		String path = null;
		String vFile = null;
		for (File bpcsFile : filesInDir) {
			try {
				path = bpcsFile.getAbsolutePath();
				if (path.contains("_Bpcs")) {
					vFile = path.substring(0, path.lastIndexOf("_"))
							+ "_Vastera.xml";
					vasteraFile = new File(vFile);

					// If vastera file doesnt exists create it from copying the
					// contents of the corresponding BPCS xml
					// file
					if (!vasteraFile.exists()) {
						Files.copy(bpcsFile.toPath(), vasteraFile.toPath());
						vasteraFile.setLastModified(bpcsFile.lastModified());
					} else {
						log.info("Vastera file already exists : " + vasteraFile);
					}
				}
			} catch (IOException ioEx) {
				log.error("Replication failed for fie : " + path);
				ioEx.printStackTrace();
				throw new InterfaceException("Replication failed for fie : "
						+ path, ioEx);
			}
		}

	}

	/**
	 * Method to check if the output folder has BPCS xml file
	 * 
	 * @param siteAxmlFldr
	 *            output folder path
	 * @return boolean
	 */
	public boolean checkHasBPCSXML(String siteAxmlFldr) {

		File[] xmlFiles = new File(siteAxmlFldr).listFiles();
		String path = null;
		for (File file : xmlFiles) {
			path = file.getAbsolutePath();
			if (path.contains("_Bpcs")) {
				return true;
			}
		}
		return false;
	}

	/**
	 * Method to check if the output folder has Vastera xml file
	 * 
	 * @param siteAxmlFldr
	 *            output folder path
	 * @return boolean
	 */
	public boolean checkHasVasteraXML(String siteAxmlFldr) {

		File[] xmlFiles = new File(siteAxmlFldr).listFiles();
		String path = null;
		for (File file : xmlFiles) {
			path = file.getAbsolutePath();
			if (path.contains("_Vastera")) {
				return true;
			}
		}
		return false;
	}
}