package com.agile.cah.eit.plm.xmltools;

import java.io.File;

import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.TransformerFactory;

import org.w3c.dom.Document;

/**
 * Description : XML converter interface
 * 
 * @author rasmi.raghavan
 * @version 1.0
 * 
 * @Created : Apr 15, 2018
 * 
 *          Added for CAH Agile Release 7.0
 */
public abstract class XMLConverter {

	protected DocumentBuilderFactory factory = null;
	protected Document document;
	protected TransformerFactory transFactory = null;
	protected File styleSheet = null;
	protected File dataFile = null;

	XMLConverter(String xslFileName, String dataFileName) {
		factory = DocumentBuilderFactory.newInstance();
		transFactory = javax.xml.transform.TransformerFactory.newInstance();
		styleSheet = new File(xslFileName);
		dataFile = new File(dataFileName);
	}

	public abstract boolean transformXML(String opXmlName, String xslFileName);

}
