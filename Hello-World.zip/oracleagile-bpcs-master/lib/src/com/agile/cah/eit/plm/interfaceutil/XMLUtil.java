package com.agile.cah.eit.plm.interfaceutil;

import java.io.StringReader;
import java.io.StringWriter;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.Document;
import org.xml.sax.InputSource;

/**
 * Description : Util class for parsing the XML file
 * 
 * @author rasmi.raghavan
 * @version 1.0
 * 
 * @Created : Apr 15, 2018
 * 
 *          Added for CAH Agile Release 7.0
 */
public class XMLUtil {

	/**
	 * Parse the xml file and return a document object
	 * 
	 * @param fileAbsPath
	 *            File Absolute path of xml file
	 * @return Document
	 * @throws Exception
	 */
	public static Document parseXml(String fileAbsPath) throws Exception {
		DocumentBuilderFactory documentBuilderFactory = DocumentBuilderFactory
				.newInstance();
		DocumentBuilder documentBuilder = documentBuilderFactory
				.newDocumentBuilder();
		return documentBuilder.parse(fileAbsPath);
	}

	/**
	 * Method to parse the XML file and return the contents as String
	 * 
	 * @param document
	 *            Document object of the XML file
	 * @return String having the XML data
	 * @throws Exception
	 */
	public static String getXmlAsString(Document document) throws Exception {
		TransformerFactory tf = TransformerFactory.newInstance();
		Transformer transformer = tf.newTransformer();
		transformer.setOutputProperty(OutputKeys.OMIT_XML_DECLARATION, "yes");
		StringWriter writer = new StringWriter();
		transformer
				.transform(new DOMSource(document), new StreamResult(writer));
		String output = writer.getBuffer().toString().replaceAll("\n|\r", "");
		return output;
	}

	/**
	 * Method to convert String of XML data to Document object
	 * 
	 * @param xmlString
	 *            String of XML data
	 * @return Document
	 * @throws Exception
	 */
	public static Document getXmlAsDOMDocument(String xmlString)
			throws Exception {
		DocumentBuilderFactory documentBuilderFactory = DocumentBuilderFactory
				.newInstance();
		DocumentBuilder documentBuilder = documentBuilderFactory
				.newDocumentBuilder();
		return documentBuilder.parse(new InputSource(
				new StringReader(xmlString)));
	}
}
