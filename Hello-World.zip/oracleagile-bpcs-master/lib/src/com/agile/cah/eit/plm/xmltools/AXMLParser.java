package com.agile.cah.eit.plm.xmltools;

import java.io.File;
import java.io.IOException;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpression;
import javax.xml.xpath.XPathFactory;

import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import com.agile.cah.eit.plm.interfaceBean.AXMLDataBean;
import com.agile.cah.eit.plm.interfaceutil.InterfaceConstants;
import com.agile.cah.eit.plm.interfaceutil.InterfaceException;

/**
 * Description : Parser implementation class to read AXMl file
 * 
 * @author rasmi.raghavan
 * @version 1.0
 * 
 * @Created : Apr 15, 2018
 * 
 *          Added for CAH Agile Release 7.0
 */
public class AXMLParser {

	static org.apache.logging.log4j.Logger log;

	static {
		log = org.apache.logging.log4j.LogManager.getLogger(AXMLParser.class);
	}

	/**
	 * Method to read attributes from AXML file
	 * 
	 * @param axmlFile
	 *            AXML file
	 * @return AXMLDataBean
	 * @throws InterfaceException
	 */
	public AXMLDataBean readAttributes(File axmlFile) throws InterfaceException {
		AXMLDataBean axmlBean = new AXMLDataBean();
		try {
			DocumentBuilderFactory dbFactory = DocumentBuilderFactory
					.newInstance();
			DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
			Document doc = dBuilder.parse(axmlFile);

			XPathFactory xPathfactory = XPathFactory.newInstance();
			XPath xpath = xPathfactory.newXPath();

			// Read selected Object type
			String type = getXmlTagValue(xpath, doc,
					InterfaceConstants.SELECTED_OBJECT_TYPE);
			axmlBean.setSelectedObjType(type);
			log.info("Selected Object Type value == " + type);

			// Read selected Object Number
			String selObjNo = getXmlTagValue(xpath, doc,
					InterfaceConstants.SELECTED_OBJECT_NUMBER);
			axmlBean.setSelectedObjNo(selObjNo);
			log.info("Selected Object No value == " + selObjNo);

			// Read selected ATO Number
			String atoNo = getXmlTagValue(xpath, doc,
					InterfaceConstants.ATO_NUMBER);
			axmlBean.setAto_number(atoNo);
			log.info("ATO No value == " + atoNo);

			// // Read selected Site ID/Number
			String siteID = "";
			if (type.equals("ECO") || type.equals("DMCO")) {
				siteID = getXmlTagValue(xpath, doc,
						InterfaceConstants.ECO_SITE_CODE);
			} else if (type.equals("SCO")) {
				siteID = getXmlTagValue(xpath, doc,
						InterfaceConstants.SCO_SITE_CODE);
			} else if (type.equals("MCO")) {
				siteID = getXmlTagValue(xpath, doc,
						InterfaceConstants.MCO_SITE_CODE);
			}
			axmlBean.setSiteID(siteID);
			log.info("Site ID value == " + siteID);

		} catch (ParserConfigurationException parserConfEx) {
			log.error("ParserConfigurationException");
			throw new InterfaceException("Exception while parsing AXML ",
					parserConfEx);
		} catch (IOException ioEx) {
			log.error("IOException");
			throw new InterfaceException("Exception while parsing AXML ", ioEx);
		} catch (SAXException saxEx) {
			log.error("SAXException");
			throw new InterfaceException("Exception while parsing AXML ", saxEx);
		} catch (InterfaceException intrEx) {
			log.error("InterfaceException");
			throw new InterfaceException(intrEx.getMessage(), intrEx);
		} catch (Exception ex) {
			log.error("Exception");
			throw new InterfaceException("Exception while parsing AXML ", ex);
		}
		return axmlBean;
	}

	/**
	 * Method to get the XML tag value
	 * 
	 * @param xpath
	 *            XPATH for the xml tag
	 * @param doc
	 *            XML Document
	 * @param tageNameExp
	 *            Tag Name
	 * @return String
	 * @throws InterfaceException
	 */
	public String getXmlTagValue(XPath xpath, Document doc, String tageNameExp)
			throws InterfaceException {
		String value = "";
		try {
			XPathExpression expr = xpath.compile(tageNameExp);
			NodeList nl = (NodeList) expr.evaluate(doc, XPathConstants.NODESET);
			value = nl.item(0).getTextContent();

		} catch (Exception ex) {
			throw new InterfaceException("Error reading tag : " + tageNameExp);
		}
		return value;
	}

}
