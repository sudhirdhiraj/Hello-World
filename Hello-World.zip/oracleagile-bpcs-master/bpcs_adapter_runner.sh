#!/bin/sh

# This file is used to setup the necessary classpath to run the Adapter
umask 000
#JAVA_HOME=/data/java/jdk1.8.0_172
JAVA_HOME=/data/java/jdk
APPDIR=/data/oracle/CAHTools/bpcsintergration
#APPDIR=`dirname $0`
LIBDIR=$APPDIR/lib

export APPDIR

PROPERTY_FILE_CONFIG=/data/oracle/CAHTools/bpcsintergration/config/AgileToBPCSInterface.properties
export PROPERTY_FILE_CONFIG

PROPERTY_FILE_CONFIG3=/data/oracle/CAHTools/bpcsintergration/config/log4j2_XMLCreation.xml
export PROPERTY_FILE_CONFIG3


cp=$APPDIR/config
cp=$cp:$LIBDIR/bpcs.jar
cp=$cp:$LIBDIR/org.mozilla.javascript-1.7.2.jar
cp=$cp:$LIBDIR/org-apache-commons-logging.jar
cp=$cp:$LIBDIR/js-1.7R3.jar
cp=$cp:$LIBDIR/bsf-2.4.jar
cp=$cp:$LIBDIR/saxon9he.jar
cp=$cp:$LIBDIR/log4j-api.jar
cp=$cp:$LIBDIR/log4j-core.jar
#cp=$cp:$LIBDIR/log4j.jar
cp=$cp:$LIBDIR/com.ibm.mq.traceControl.jar
cp=$cp:$LIBDIR/com.ibm.mq.allclient.jar
cp=$cp:$LIBDIR/javax.mail.jar
cp=$cp:$LIBDIR/javax.jms.jar
cp=$cp:$LIBDIR/apache-activemq-5.0.0.jar
cp=$cp:$LIBDIR/apache-activemq-4.1.1.jar

count=`ps -ef |grep -c bpcs_ad`
if [ "$count" -lt 5 ]
then
$JAVA_HOME/bin/java -Dlog4j.configurationFile=file:$APPDIR/config/log4j2_XMLCreation.xml -Xms256m -Xmx1024m -classpath $cp com.agile.cah.eit.plm.integrator.ProcessAgileData
fi
output=$?
echo $output
exit $output
